import io
import os
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import get_db
from models import Wilayah, Kandidat, Voucher, VotingSession, Vote, Admin, ActivityLog
from security import hash_password, check_password, random_password

router = APIRouter(prefix='/admin')

UPLOAD_DIR = Path('static/uploads')
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def admin_auth(request: Request):
    if not request.session.get('admin_id'):
        raise HTTPException(status_code=401, detail='belum login')


def tulis_log(db, request, jenis, keterangan=None):
    ip = request.client.host if request.client else None
    db.add(ActivityLog(admin_id=request.session.get('admin_id'),
                       jenis=jenis, keterangan=keterangan, ip=ip))


def simpan_foto(foto: UploadFile, kandidat_id: int) -> str:
    ext = os.path.splitext(foto.filename)[1].lower()
    if ext not in ('.jpg', '.jpeg', '.png', '.webp'):
        ext = '.jpg'
    nama_file = 'kandidat_%d%s' % (kandidat_id, ext)
    with open(UPLOAD_DIR / nama_file, 'wb') as f:
        f.write(foto.file.read())
    return '/static/uploads/' + nama_file


# ---------- halaman ----------

@router.get('')
def halaman_admin():
    return FileResponse('static/admin.html')


# ---------- auth admin ----------

class AdminLogin(BaseModel):
    username: str
    password: str


@router.post('/api/login')
def login_admin(data: AdminLogin, request: Request, db: Session = Depends(get_db)):
    admin = db.query(Admin).filter_by(username=data.username.strip()).first()
    if not admin or not check_password(data.password, admin.password_hash):
        return {'ok': False, 'msg': 'Username atau password salah.'}
    request.session.clear()
    request.session['admin_id'] = admin.id
    tulis_log(db, request, 'ADMIN_LOGIN')
    db.commit()
    return {'ok': True}


@router.post('/api/logout')
def logout_admin(request: Request):
    request.session.clear()
    return {'ok': True}


class GantiPass(BaseModel):
    password_lama: str
    password_baru: str


@router.post('/api/ganti-password')
def ganti_password(data: GantiPass, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    admin = db.get(Admin, request.session['admin_id'])
    if not admin or not check_password(data.password_lama, admin.password_hash):
        return {'ok': False, 'msg': 'Password lama salah.'}
    if len(data.password_baru) < 8:
        return {'ok': False, 'msg': 'Password baru minimal 8 karakter.'}
    admin.password_hash = hash_password(data.password_baru)
    tulis_log(db, request, 'GANTI_PASSWORD')
    db.commit()
    return {'ok': True}


# ---------- wilayah ----------

class WilayahIn(BaseModel):
    kode_pos: str
    nama: str


@router.get('/api/wilayah')
def list_wilayah(request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    hasil = []
    for w in db.query(Wilayah).order_by(Wilayah.kode_pos).all():
        total = db.query(Voucher).filter_by(wilayah_id=w.id).count()
        pakai = db.query(Voucher).filter_by(wilayah_id=w.id, status='TERPAKAI').count()
        hasil.append({'id': w.id, 'kode_pos': w.kode_pos, 'nama': w.nama,
                      'total': total, 'terpakai': pakai})
    return hasil


@router.post('/api/wilayah')
def tambah_wilayah(data: WilayahIn, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    if db.query(Wilayah).filter_by(kode_pos=data.kode_pos.strip()).first():
        return {'ok': False, 'msg': 'Kode pos sudah terdaftar.'}
    db.add(Wilayah(kode_pos=data.kode_pos.strip(), nama=data.nama.strip()))
    tulis_log(db, request, 'TAMBAH_WILAYAH', data.nama)
    db.commit()
    return {'ok': True}


@router.delete('/api/wilayah/{wid}')
def hapus_wilayah(wid: int, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    w = db.get(Wilayah, wid)
    if not w:
        return {'ok': False}
    if db.query(Voucher).filter_by(wilayah_id=wid).count() > 0:
        return {'ok': False, 'msg': 'Wilayah masih punya voucher, tidak bisa dihapus.'}
    db.delete(w)
    tulis_log(db, request, 'HAPUS_WILAYAH', w.nama)
    db.commit()
    return {'ok': True}


# ---------- kandidat ----------

@router.get('/api/kandidat')
def list_kandidat(request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    rows = db.query(Kandidat).order_by(Kandidat.urutan, Kandidat.id).all()
    return [{'id': k.id, 'nama': k.nama, 'foto': k.foto,
             'urutan': k.urutan, 'aktif': k.aktif} for k in rows]


@router.post('/api/kandidat')
async def tambah_kandidat(request: Request, nama: str = Form(...),
                          urutan: int = Form(0), foto: UploadFile = File(None),
                          db: Session = Depends(get_db)):
    admin_auth(request)
    k = Kandidat(nama=nama.strip(), urutan=urutan)
    db.add(k)
    db.flush()
    if foto and foto.filename:
        k.foto = simpan_foto(foto, k.id)
    tulis_log(db, request, 'TAMBAH_KANDIDAT', k.nama)
    db.commit()
    return {'ok': True, 'id': k.id}


@router.put('/api/kandidat/{kid}')
async def ubah_kandidat(kid: int, request: Request, nama: str = Form(...),
                        urutan: int = Form(0), aktif: int = Form(1),
                        foto: UploadFile = File(None),
                        db: Session = Depends(get_db)):
    admin_auth(request)
    k = db.get(Kandidat, kid)
    if not k:
        return {'ok': False}
    k.nama = nama.strip()
    k.urutan = urutan
    k.aktif = aktif
    if foto and foto.filename:
        k.foto = simpan_foto(foto, k.id)
    tulis_log(db, request, 'UBAH_KANDIDAT', k.nama)
    db.commit()
    return {'ok': True}


# ---------- voucher ----------

class GenerateIn(BaseModel):
    wilayah_id: int
    jumlah: int
    kuota: int


@router.post('/api/voucher/generate')
def generate_voucher(data: GenerateIn, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    w = db.get(Wilayah, data.wilayah_id)
    if not w:
        return {'ok': False, 'msg': 'Wilayah tidak ditemukan.'}
    jml_kandidat = db.query(Kandidat).filter_by(aktif=1).count()
    if data.kuota < 1 or data.kuota > jml_kandidat:
        return {'ok': False, 'msg': 'Kuota harus 1 sampai ' + str(jml_kandidat) +
                ' (jumlah kandidat aktif).'}
    if data.jumlah < 1 or data.jumlah > 999:
        return {'ok': False, 'msg': 'Jumlah voucher per batch maksimal 999.'}

    last = (db.query(Voucher).filter_by(wilayah_id=w.id)
            .order_by(Voucher.nomor_urut.desc()).first())
    start = (last.nomor_urut + 1) if last else 1
    if start + data.jumlah - 1 > 999:
        return {'ok': False, 'msg': 'Nomor urut wilayah ini sudah penuh (maks 999).'}

    dibuat = []
    for i in range(start, start + data.jumlah):
        pw = random_password()
        username = '%s%03d' % (w.kode_pos, i)
        v = Voucher(wilayah_id=w.id, nomor_urut=i, username=username,
                    password_hash=hash_password(pw), kuota=data.kuota, status='BARU')
        db.add(v)
        db.flush()
        dibuat.append({'id': v.id, 'username': username, 'password': pw})
    tulis_log(db, request, 'GENERATE_VOUCHER',
              '%s: %d voucher, kuota %d' % (w.nama, data.jumlah, data.kuota))
    db.commit()
    return {'ok': True, 'voucher': dibuat}


@router.get('/api/voucher')
def list_voucher(wilayah_id: int, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    w = db.get(Wilayah, wilayah_id)
    if not w:
        return {'ok': False, 'msg': 'Wilayah tidak ditemukan.'}
    rows = (db.query(Voucher).filter_by(wilayah_id=wilayah_id)
            .order_by(Voucher.nomor_urut).all())
    return {'kode_pos': w.kode_pos, 'nama_wilayah': w.nama, 'items': [{
        'id': v.id, 'username': v.username, 'nomor_urut': v.nomor_urut,
        'nama': v.nama or '', 'asal_pimpinan': v.asal_pimpinan or '',
        'kuota': v.kuota, 'status': v.status} for v in rows]}


class VoucherEdit(BaseModel):
    nama: str | None = None
    asal_pimpinan: str | None = None


@router.put('/api/voucher/{vid}')
def edit_voucher(vid: int, data: VoucherEdit, request: Request,
                 db: Session = Depends(get_db)):
    admin_auth(request)
    v = db.get(Voucher, vid)
    if not v:
        return {'ok': False}
    if data.nama is not None:
        v.nama = data.nama.strip() or None
    if data.asal_pimpinan is not None:
        v.asal_pimpinan = data.asal_pimpinan.strip() or None
    db.commit()
    return {'ok': True}


def reset_voucher(db, v: Voucher, request: Request, jenis: str):
    # hapus semua sesi dan suara voucher, kembalikan ke BARU
    sesi_ids = [s.id for s in db.query(VotingSession).filter_by(voucher_id=v.id).all()]
    for sid in sesi_ids:
        db.query(Vote).filter_by(session_id=sid).delete()
    db.query(VotingSession).filter_by(voucher_id=v.id).delete()
    v.status = 'BARU'
    tulis_log(db, request, jenis, v.username)


@router.post('/api/voucher/{vid}/regenerate')
def regenerate_password(vid: int, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    v = db.get(Voucher, vid)
    if not v:
        return {'ok': False}
    if v.status == 'TERPAKAI':
        return {'ok': False, 'msg': 'Voucher sudah voting. Gunakan Recovery bila perlu.'}
    reset_voucher(db, v, request, 'REGENERATE_VOUCHER')
    pw = random_password()
    v.password_hash = hash_password(pw)
    db.commit()
    return {'ok': True, 'username': v.username, 'password': pw}


@router.post('/api/voucher/{vid}/recover')
def recover_voucher(vid: int, request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    v = db.get(Voucher, vid)
    if not v:
        return {'ok': False}
    reset_voucher(db, v, request, 'RECOVERY_VOUCHER')
    db.commit()
    return {'ok': True, 'username': v.username}


# ---------- hasil ----------

@router.get('/api/hasil')
def hasil_voting(request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    kandidat = (db.query(Kandidat).filter_by(aktif=1)
                .order_by(Kandidat.urutan, Kandidat.id).all())
    total_suara = db.query(Vote).count()
    data = []
    for k in kandidat:
        n = db.query(Vote).filter_by(kandidat_id=k.id).count()
        data.append({'id': k.id, 'nama': k.nama, 'suara': n,
                     'persen': round(n / total_suara * 100, 2) if total_suara else 0})
    total_voucher = db.query(Voucher).count()
    sudah = db.query(Voucher).filter_by(status='TERPAKAI').count()
    return {'kandidat': data,
            'total_suara': total_suara,
            'total_voucher': total_voucher,
            'sudah_vote': sudah,
            'belum_vote': total_voucher - sudah}


# ---------- log ----------

@router.get('/api/log')
def log_aktivitas(request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    rows = db.query(ActivityLog).order_by(ActivityLog.id.desc()).limit(500).all()
    out = []
    for r in rows:
        username = None
        if r.voucher_id:
            v = db.get(Voucher, r.voucher_id)
            username = v.username if v else None
        admin_name = None
        if r.admin_id:
            a = db.get(Admin, r.admin_id)
            admin_name = a.username if a else None
        waktu = r.waktu.strftime('%Y-%m-%d %H:%M:%S') if r.waktu else ''
        out.append({'waktu': waktu, 'jenis': r.jenis, 'username': username,
                    'admin': admin_name, 'keterangan': r.keterangan or '',
                    'ip': r.ip or ''})
    return out


# ---------- export excel ----------

@router.get('/api/export')
def export_excel(request: Request, db: Session = Depends(get_db)):
    admin_auth(request)
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, Reference

    wb = Workbook()
    ws = wb.active
    ws.title = 'Hasil Voting'
    ws.append(['Kandidat', 'Suara', 'Persentase (%)'])
    kandidat = (db.query(Kandidat).filter_by(aktif=1)
                .order_by(Kandidat.urutan, Kandidat.id).all())
    total = db.query(Vote).count()
    for k in kandidat:
        n = db.query(Vote).filter_by(kandidat_id=k.id).count()
        ws.append([k.nama, n, round(n / total * 100, 2) if total else 0])
    chart = BarChart()
    chart.title = 'Hasil Voting'
    data_ref = Reference(ws, min_col=2, min_row=1, max_row=1 + len(kandidat))
    cats = Reference(ws, min_col=1, min_row=2, max_row=1 + len(kandidat))
    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 10
    chart.width = 22
    ws.add_chart(chart, 'E2')

    ws2 = wb.create_sheet('Log Aktivitas')
    ws2.append(['Waktu', 'Jenis', 'Username Voucher', 'Admin', 'Keterangan', 'IP'])
    rows = db.query(ActivityLog).order_by(ActivityLog.id.asc()).all()
    for r in rows:
        v = db.get(Voucher, r.voucher_id) if r.voucher_id else None
        a = db.get(Admin, r.admin_id) if r.admin_id else None
        waktu = r.waktu.strftime('%Y-%m-%d %H:%M:%S') if r.waktu else ''
        ws2.append([waktu, r.jenis, v.username if v else '',
                    a.username if a else '', r.keterangan or '', r.ip or ''])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    tulis_log(db, request, 'EXPORT_EXCEL')
    db.commit()
    return StreamingResponse(
        buf,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': 'attachment; filename=hasil_voting.xlsx'})
