document.getElementById('form-login').addEventListener('submit', function (e) {
  e.preventDefault();
  var pesan = document.getElementById('pesan');
  pesan.textContent = '';
  fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: document.getElementById('username').value.trim(),
      password: document.getElementById('password').value
    })
  }).then(function (r) { return r.json(); }).then(function (d) {
    if (d.ok) {
      location.href = '/vote';
    } else {
      pesan.textContent = d.msg || 'Login gagal.';
    }
  }).catch(function () {
    pesan.textContent = 'Terjadi kesalahan jaringan.';
  });
});
