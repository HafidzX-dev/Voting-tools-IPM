var kuota = 0;
var dipilih = [];

function esc(s) {
  var d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function refreshInfo() {
  var sisa = kuota - dipilih.length;
  document.getElementById('info-kuota').textContent =
    'Wajib memilih ' + kuota + ' kandidat. Tersisa ' + sisa + ' pilihan.';
  document.getElementById('btn-submit').disabled = (sisa !== 0);
}

fetch('/api/kandidat').then(function (r) { return r.json(); }).then(function (d) {
  if (!d.ok) { location.href = '/'; return; }
  kuota = d.kuota;
  var daftar = document.getElementById('daftar');
  d.kandidat.forEach(function (k) {
    var el = document.createElement('div');
    el.className = 'kandidat';
    el.innerHTML = '<img src="' + (k.foto || '/static/assets/logo.png') +
      '" alt=""><div class="nama">' + esc(k.nama) + '</div>';
    el.onclick = function () {
      var idx = dipilih.indexOf(k.id);
      if (idx >= 0) {
        dipilih.splice(idx, 1);
        el.classList.remove('dipilih');
      } else if (dipilih.length < kuota) {
        dipilih.push(k.id);
        el.classList.add('dipilih');
      }
      refreshInfo();
    };
    daftar.appendChild(el);
  });
  refreshInfo();
});

document.getElementById('btn-submit').addEventListener('click', function () {
  var pesan = document.getElementById('pesan');
  pesan.textContent = '';
  fetch('/api/vote', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ kandidat_ids: dipilih })
  }).then(function (r) { return r.json(); }).then(function (d) {
    if (d.ok) {
      location.href = '/static/thanks.html';
    } else {
      pesan.textContent = d.msg || 'Gagal menyimpan suara.';
    }
  }).catch(function () {
    pesan.textContent = 'Terjadi kesalahan jaringan.';
  });
});
