var wilayahList = [];

function api(url, opts) {
  return fetch(url, opts).then(function (r) {
    if (r.status === 401) { tampilkanLogin(); throw new Error('unauthorized'); }
    return r.json();
  });
}

function post(url, obj) {
  return api(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(obj)
  });
}

function esc(s) {
  var d = document.createElement('div');
  d.textContent = (s == null) ? '' : String(s);
  return d.innerHTML;
}

function tampilkanLogin() {
  document.getElementById('login-wrap').style.display = 'flex';
  document.getElementById('app-wrap').style.display = 'none';
}

function tampilkanApp() {
  document.getElementById('login-wrap').style.display = 'none';
  document.getElementById('app-wrap').style.display = 'block';
  muatSemua();
}

// ---------- login admin ----------

document.getElementById('form-admin-login').addEventListener('submit', function (e) {
  e.preventDefault();
  post('/admin/api/login', {
    username: document.getElementById('a-username').value.trim(),
    password: document.getElementById('a-password').value
  }).then(function (d) {
    if (d.ok) { tampilkanApp(); }
    else { document.getElementById('a-pesan').textContent = d.msg || 'Login gagal.'; }
  });
});

document.getElementById('btn-keluar').addEventListener('click', function () {
  post('/admin/api/logout', {}).then(function () { tampilkanLogin(); });
});

// ---------- tab ----------

document.querySelectorAll('.tab-btn').forEach(function (b) {
  b.addEventListener('click', function () {
    document.querySelectorAll('.tab-btn').forEach(function (x) { x.classList.remove('active'); });
    document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('active'); });
    b.classList.add('active');
    document.getElementById('tab-' + b.dataset.tab).classList.add('active');
    if (b.dataset.tab === 'hasil') { muatHasil(); }
    if (b.dataset.tab === 'log') { muatLog(); }
  });
});

// ---------- wilayah ----------

function muatWilayah() {
  return api('/admin/api/wilayah').then(function (rows) {
    wilayahList = rows;
    var tbody = document.querySelector('#tbl-wilayah tbody');
    tbody.innerHTML = '';
    rows.forEach(function (w) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + esc(w.kode_pos) + '</td><td>' + esc(w.nama) + '</td>' +
        '<td>' + w.total + '</td><td>' + w.terpakai + '</td>' +
        '<td><button class="danger" data-id="' + w.id + '">Hapus</button></td>';
      tbody.appendChild(tr);
    });
    var sel = document.getElementById('g-wilayah');
    sel.innerHTML = '';
    rows.forEach(function (w) {
      var o = document.createElement('option');
      o.value = w.id;
      o.textContent = w.kode_pos + ' - ' + w.nama;
      sel.appendChild(o);
    });
    if (rows.length) { muatVoucher(parseInt(sel.value)); }
    else {
      document.querySelector('#tbl-voucher tbody').innerHTML =
        '<tr><td colspan="6">Belum ada wilayah. Tambahkan dulu di tab Wilayah.</td></tr>';
    }
  });
}

document.getElementById('btn-tambah-wilayah').addEventListener('click', function () {
  var kode = document.getElementById('w-kode').value.trim();
  var nama = document.getElementById('w-nama').value.trim();
  if (!/^[0-9]{5}$/.test(kode)) { alert('Kode pos harus 5 digit angka.'); return; }
  if (!nama) { alert('Nama wilayah wajib diisi.'); return; }
  post('/admin/api/wilayah', { kode_pos: kode, nama: nama }).then(function (d) {
    if (d.ok) {
      document.getElementById('w-kode').value = '';
      document.getElementById('w-nama').value = '';
      muatWilayah();
    } else { alert(d.msg || 'Gagal.'); }
  });
});

document.querySelector('#tbl-wilayah').addEventListener('click', function (e) {
  if (e.target.tagName !== 'BUTTON') { return; }
  var id = e.target.dataset.id;
  if (confirm('Hapus wilayah ini?')) {
    api('/admin/api/wilayah/' + id, { method: 'DELETE' }).then(function (d) {
      if (d.ok) { muatWilayah(); } else { alert(d.msg || 'Gagal.'); }
    });
  }
});

// ---------- voucher ----------

function muatVoucher(wilayahId) {
  if (!wilayahId) { return; }
  api('/admin/api/voucher?wilayah_id=' + wilayahId).then(function (d) {
    if (!d.ok) { return; }
    document.getElementById('v-wilayah-nama').textContent =
      '- ' + d.kode_pos + ' ' + d.nama_wilayah;
    var tbody = document.querySelector('#tbl-voucher tbody');
    tbody.innerHTML = '';
    d.items.forEach(function (v) {
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td>' + esc(v.username) + '</td>' +
        '<td><input class="edit-nama" data-id="' + v.id + '" value="' + esc(v.nama) + '" placeholder="Nama"></td>' +
        '<td><input class="edit-asal" data-id="' + v.id + '" value="' + esc(v.asal_pimpinan) + '" placeholder="Asal pimpinan"></td>' +
        '<td>' + v.kuota + '</td>' +
        '<td>' + (v.status === 'TERPAKAI' ? 'Sudah voting' : 'Belum') + '</td>' +
        '<td>' +
        '<button class="v-print" data-u="' + esc(v.username) + '" data-n="' + esc(v.nama) +
        '" data-a="' + esc(v.asal_pimpinan) + '" data-p="">Cetak</button> ' +
        '<button class="v-regen" data-id="' + v.id + '">Password Baru</button> ' +
        '<button class="v-recover danger" data-id="' + v.id + '">Recovery</button>' +
        '</td>';
      tbody.appendChild(tr);
    });
  });
}

document.getElementById('g-wilayah').addEventListener('change', function () {
  muatVoucher(parseInt(this.value));
});

document.getElementById('btn-generate').addEventListener('click', function () {
  var wilayahId = parseInt(document.getElementById('g-wilayah').value);
  if (!wilayahId) { alert('Tambahkan wilayah dulu.'); return; }
  post('/admin/api/voucher/generate', {
    wilayah_id: wilayahId,
    jumlah: parseInt(document.getElementById('g-jumlah').value),
    kuota: parseInt(document.getElementById('g-kuota').value)
  }).then(function (d) {
    if (!d.ok) { alert(d.msg || 'Gagal generate.'); return; }
    var w = wilayahList.filter(function (x) { return x.id === wilayahId; })[0];
    var psw = {};
    d.voucher.forEach(function (v) { psw[v.username] = v.password; });
    sessionStorage.setItem('cetak_voucher', JSON.stringify(d.voucher.map(function (v) {
      return { username: v.username, password: v.password, nama: '', asal_pimpinan: w.nama };
    })));
    window.open('/static/cetak.html', '_blank');
    muatWilayah();
  });
});

// simpan nama/asal otomatis saat input kehilangan fokus
document.querySelector('#tbl-voucher').addEventListener('focusout', function (e) {
  if (e.target.classList.contains('edit-nama') || e.target.classList.contains('edit-asal')) {
    var body = {};
    body[e.target.classList.contains('edit-nama') ? 'nama' : 'asal_pimpinan'] = e.target.value;
    api('/admin/api/voucher/' + e.target.dataset.id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }
});

document.querySelector('#tbl-voucher').addEventListener('click', function (e) {
  var t = e.target;
  if (t.classList.contains('v-print')) {
    var v = [{ username: t.dataset.u, nama: t.dataset.n, asal_pimpinan: t.dataset.a, password: t.dataset.p }];
    if (!t.dataset.p) {
      // cetak ulang tanpa password, tampilkan info
      if (!confirm('Password voucher tidak ditampilkan kembali untuk keamanan. Lanjut cetak identitas saja?')) { return; }
    }
    sessionStorage.setItem('cetak_voucher', JSON.stringify(v));
    window.open('/static/cetak.html', '_blank');
  }
  if (t.classList.contains('v-regen')) {
    if (confirm('Buat password baru untuk voucher ini? Password lama tidak bisa dipakai lagi.')) {
      post('/admin/api/voucher/' + t.dataset.id + '/regenerate', {}).then(function (d) {
        if (d.ok) {
          sessionStorage.setItem('cetak_voucher', JSON.stringify([d]));
          window.open('/static/cetak.html', '_blank');
          muatWilayah();
        } else { alert(d.msg || 'Gagal.'); }
      });
    }
  }
  if (t.classList.contains('v-recover')) {
    if (confirm('Recovery akan MENGHAPUS semua suara voucher ini dan voucher bisa dipakai ulang. Yakin?')) {
      post('/admin/api/voucher/' + t.dataset.id + '/recover', {}).then(function (d) {
        if (d.ok) { alert('Voucher ' + d.username + ' berhasil di-reset.'); muatWilayah(); }
        else { alert(d.msg || 'Gagal.'); }
      });
    }
  }
});

// ---------- kandidat ----------

function muatKandidat() {
  api('/admin/api/kandidat').then(function (rows) {
    var tbody = document.querySelector('#tbl-kandidat tbody');
    tbody.innerHTML = '';
    rows.forEach(function (k) {
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td><img src="' + (k.foto || '/static/assets/logo.png') + '"></td>' +
        '<td>' + esc(k.nama) + '</td><td>' + k.urutan + '</td>' +
        '<td>' + (k.aktif ? 'Ya' : 'Tidak') + '</td>' +
        '<td><button class="k-toggle" data-id="' + k.id + '" data-aktif="' + k.aktif +
        '" data-nama="' + esc(k.nama) + '" data-urutan="' + k.urutan + '">' +
        (k.aktif ? 'Nonaktifkan' : 'Aktifkan') + '</button></td>';
      tbody.appendChild(tr);
    });
  });
}

document.getElementById('btn-tambah-kandidat').addEventListener('click', function () {
  var nama = document.getElementById('k-nama').value.trim();
  if (!nama) { alert('Nama kandidat wajib diisi.'); return; }
  var fd = new FormData();
  fd.append('nama', nama);
  fd.append('urutan', document.getElementById('k-urutan').value);
  var foto = document.getElementById('k-foto').files[0];
  if (foto) { fd.append('foto', foto); }
  api('/admin/api/kandidat', { method: 'POST', body: fd }).then(function (d) {
    if (d.ok) {
      document.getElementById('k-nama').value = '';
      document.getElementById('k-foto').value = '';
      muatKandidat();
    } else { alert(d.msg || 'Gagal.'); }
  });
});

document.querySelector('#tbl-kandidat').addEventListener('click', function (e) {
  if (!e.target.classList.contains('k-toggle')) { return; }
  var t = e.target;
  var fd = new FormData();
  fd.append('nama', t.dataset.nama);
  fd.append('urutan', t.dataset.urutan);
  fd.append('aktif', t.dataset.aktif === '1' ? '0' : '1');
  api('/admin/api/kandidat/' + t.dataset.id, { method: 'PUT', body: fd }).then(function (d) {
    if (d.ok) { muatKandidat(); }
  });
});

// ---------- hasil ----------

var timerHasil = null;

function muatHasil() {
  api('/admin/api/hasil').then(function (d) {
    document.getElementById('stat').innerHTML =
      '<div class="stat"><span class="angka">' + d.sudah_vote + '</span>Sudah voting</div>' +
      '<div class="stat"><span class="angka">' + d.belum_vote + '</span>Belum voting</div>' +
      '<div class="stat"><span class="angka">' + d.total_suara + '</span>Total suara masuk</div>';
    var g = document.getElementById('grafik');
    g.innerHTML = '';
    var max = 1;
    d.kandidat.forEach(function (k) { if (k.suara > max) { max = k.suara; } });
    d.kandidat.forEach(function (k) {
      var lebar = Math.round(k.suara / max * 100);
      var row = document.createElement('div');
      row.className = 'bar-row';
      row.innerHTML =
        '<div class="bar-label">' + esc(k.nama) + ' — ' + k.suara + ' suara (' + k.persen + '%)</div>' +
        '<div class="bar-wrap"><div class="bar" style="width:' + Math.max(lebar, 1) + '%">' +
        '<span class="bar-isi"></span></div></div>';
      g.appendChild(row);
    });
  });
  if (timerHasil) { clearTimeout(timerHasil); }
  timerHasil = setTimeout(function () {
    if (document.getElementById('tab-hasil').classList.contains('active')) { muatHasil(); }
  }, 5000);
}

// ---------- log ----------

function muatLog() {
  api('/admin/api/log').then(function (rows) {
    var tbody = document.querySelector('#tbl-log tbody');
    tbody.innerHTML = '';
    rows.forEach(function (r) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + esc(r.waktu) + '</td><td>' + esc(r.jenis) + '</td>' +
        '<td>' + esc(r.username || '-') + '</td><td>' + esc(r.admin || '-') + '</td>' +
        '<td>' + esc(r.keterangan) + '</td><td>' + esc(r.ip) + '</td>';
      tbody.appendChild(tr);
    });
  });
}

// ---------- akun ----------

document.getElementById('btn-ganti-pass').addEventListener('click', function () {
  post('/admin/api/ganti-password', {
    password_lama: document.getElementById('p-lama').value,
    password_baru: document.getElementById('p-baru').value
  }).then(function (d) {
    var p = document.getElementById('p-pesan');
    p.style.color = d.ok ? '#1e7d32' : '#c0392b';
    p.textContent = d.ok ? 'Password berhasil diganti.' : (d.msg || 'Gagal.');
    if (d.ok) {
      document.getElementById('p-lama').value = '';
      document.getElementById('p-baru').value = '';
    }
  });
});

// ---------- init ----------

function muatSemua() {
  muatWilayah();
  muatKandidat();
  muatHasil();
}

// cek sesi yang mungkin masih ada
api('/admin/api/hasil').then(function () {
  tampilkanApp();
}).catch(function () {
  tampilkanLogin();
});
